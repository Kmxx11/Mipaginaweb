
const datos = {
  marte: "Marte es el cuarto planeta del sistema solar, conocido como el planeta rojo.",
  luna: "La Luna es el satélite natural de la Tierra. Ha sido visitada por astronautas en el siglo XX.",
  jupiter: "Júpiter es el planeta más grande, con una gran tormenta conocida como la Gran Mancha Roja.",
  galaxia: "Las galaxias son conjuntos enormes de estrellas, planetas, polvo y materia oscura.",
  spacex: "SpaceX es una empresa que lidera el avance aeroespacial con cohetes reutilizables y misiones hacia Marte.",
};

function buscar(event) {
  if (event.key === "Enter") {
    const valor = document.getElementById("busqueda").value.toLowerCase();
    const resultado = document.getElementById("resultados");

    if (datos[valor]) {
      resultado.innerHTML = `<p class="fade-in">${datos[valor]}</p>`;
    } else {
      resultado.innerHTML = `<p class="fade-in">No encontramos información sobre "<strong>${valor}</strong>".</p>`;
    }
  }
}

// Slideshow automático
let slideIndex = 0;
function showSlides() {
  const slides = document.getElementsByClassName("slide");
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) { slideIndex = 1; }
  slides[slideIndex - 1].style.display = "flex";
  setTimeout(showSlides, 5000); // 5 segundos
}

showSlides();
